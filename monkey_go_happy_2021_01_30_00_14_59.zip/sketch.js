
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var background, backgroundImage;
function preload(){
  
   monkey_running =            
  loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png");
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
}



function setup() {
  
  background = createSprite(0,0,600,600);
  background.addImage(backgroundImage);
  background.scale = 2.5
  
  monkey=createSprite(80,315,20,20);
  monkey.addAnimation("moving", monkey_running);
  monkey.scale=0.1;
  
  ground=createSprite(400,350,900,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  console.log(ground.x)

  obstaclesGroup = new Group();
  FoodGroup = new Group();
  
}




function draw() {
  background.velocityX = -3 
background(255);
  
   if (background.x < 100){
      background.x = background.width/2;
     
  if(ground.x<0){
    ground.x=ground.width/2
  }
     if(FoodGroup.isTouching(monkey)){
     banana.destroyEach();
     score=score+2;
     }
     
     switch (score){
         
       case 10: monkey.scale = 0.12;
         break;
         case 20: monkey.scale = 0.14;
         break;
         case 30: monkey.scale = 0.16;
         break;
         case 40: monkey.scale = 0.18;
         break;
         default: break;
          
     }
     
  if(keyDown("space")){
    monkey.velocityY=-12;
  }
  
  monkey.velocityY=monkey.velocityY+ 0.8;
  
  monkey.collide(ground);
 

       spawnFood();
      spawnobstacle();
     
     
       if(obstacleGroup.isTouching(monkey)){
         monkey.scale=0.2
       }         
  drawSprites();
  
      var survivalTime=0;
  stroke("white");
  textsize(20);
  fill("white");
  text("score: "+ score, 500, 50);
  
  stroke("black");
  textsize(20);
  fill("black");
  surviavalTime=Math.ceil(frameCount/FrameRate())
  text("survival Time: "+ survivalTime, 100, 50);
}

}
function spawnobstacle() {
if (frameCount % 300 === 0) {
    var obstacle = createSprite(800,350,10,40);
    obstacle.addImage(obstacleImage);
   obstacle.scale = 0.1;
    obstacle.velocityX = -6;
    
    obstacle.lifetime = 300;

obstacleGroup.add(obstacle);
}
}  
  function spawnFood() {
  if (frameCount % 80 === 0) {
    var banana = createSprite(600,250,40,10);
    banana.y = Math.round(random(120,200));
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -5;
    
    banana.lifetime = 300;
    
    FoodGroup.add(banana);
    
    monkey.depth= banana.depth+1;
  }
  }
    
    